<?php
namespace Tt3;

/**
 * Валидирует переданные поля формы
 *
 * @author absalyamovd
 */
class MyValidator
{
    /**
     * Массив хранения переданного в объект массива $_POST
     *
     * @var array массив данных
     */
    public $formData = [];
    
    /**
     * Функция валидации введенного email
     *
     * @return bool
     */    
    public function validateEmail()
    {
        //echo "<pre>"; print_r($this->formData); die();
        if(isset($this->formData['email'])){
            $regex = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/'; //честно из SO, но можно еще взять из RFC 
            if (!preg_match($regex, $this->formData['email']))
                    return false;
            else 
                return true;
        }
        return false;
    }
    
    /**
     * Функция валидации введенного textarea (на пустоту)
     *
     * @return bool
     */  
    public function validateTextarea()
    {
        if (trim($this->formData['textarea']) !== "")
            return true;
        else
            return false;
    }
    
}