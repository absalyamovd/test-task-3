<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="/style.css">
    <title>Title</title>
</head>
<body>
    
<?php if(isset($_GET['ok']) && $_GET['ok']='1'):?>
    <div class="ok">Форма отправлена</div>
<?php endif; ?>
    
<div class="div1">
    <form action="/action.php" method="POST" class="form1">
        <label for="email">Email:</label>
        <input type="text" name="email" id="email"  placeholder="Ваш email"/>
        <?php if(isset($_GET['emailerror']) && $_GET['emailerror']='1'):?>
            <div class="error">Ошибка в форме email!</div>
        <?php endif; ?>
        <label for="textarea">Введите текст:</label>
        <textarea name="textarea" id="textarea"  placeholder="Ваше сообщение"></textarea>
        <?php if(isset($_GET['textareaerror']) && $_GET['textareaerror']='1'):?>
            <div class="error">Ошибка в форме textarea!</div>
        <?php endif; ?>
        
        <div class="buttons">
            <input type="reset" class="button1">
            <input type="submit" class="button1">
        </div>
    </form>
</div>
</body>
</html>