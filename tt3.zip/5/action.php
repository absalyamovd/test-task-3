<?php

/**
 * 5. Написать форму обратной связи (html+php)
 * HTML форма из двух полей email и textarea
 * PHP должен принять POST запрос, проверить поля на пустоту, добавить валидацию поля email
 * и отправить данные на почту.
 * Задание должно быть выполнено с использованием регулярного выражения.
 * Весь код должен быть прокомментирован в стиле PHPDocumentor'а.
 * Гуглить можно, но запрещено использовать готовые примеры.
 */

require_once 'MyValidator.php';

$validator = new \tt3\MyValidator();
$validator->formData = $_POST;

$isEmailFieldValid = $validator->validateEmail();
$isTextareaFieldValid = $validator->validateTextarea();

$getString='';
if (!$isEmailFieldValid) {
    $getString = 'emailerror=1';
    //$errors = $validator->getErrors();
}
if (!$isTextareaFieldValid) {
    if(empty($getString)){
        $getString = 'textareaerror=1';
    }
    else{
        $getString .= '&textareaerror=1';
    }
}

if(empty($getString)){
    $to = "email@email.email";
    $subject = "Subject";
    $message = "От".$_POST['email'].":\n".$mess; // сюда не доёдем, если не пройдем валидацию
    mail($to, $subject, $message);
    header('Location: index.php?ok=1');
}
else{
    header('Location: index.php?'.$getString);
}


