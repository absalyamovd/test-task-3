<?php
/**
 * 4. Написать именно свою компоненту (не использовать стандартные) и сбросить нам
 * в виде архива. (задача на знание Bitrix Framework)
 * Компонента должна выводить список товаров из любого раздела на ваш выбор.
 * Указание ID раздела необходимо сделать через параметры компонента.
 * На странице должно отобразиться ID товара, Название товара
 * Вывод данных должен происходить в шаблоне компонента. (т.е. echo 'ID товара, Название
 * товара'; печатать в шаблоне компонента, а не в component.php)
 */

use Bitrix\Main\SystemException;

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

class GetSomeGoods extends CBitrixComponent
{
    public function executeComponent()
    {
        try {
            $this->getResult();
            $this->includeComponentTemplate();
        } catch (SystemException $e) {
            ShowError($e->getMessage());
        }
    }

    protected function getResult()
    {
        if ($this->errors)
            throw new SystemException(current($this->errors));

        $arResult = [];
        $arFilter = [
            'IBLOCK_ID' => $this->arParams['IBLOCK_ID'],
            'SECTION_ID' => $this->arParams['SECTION_ID'],
            'GLOBAL_ACTIVE' => 'Y',
            'ACTIVE' => 'Y'
        ];
        $list = CIBlockElement::GetList(["ID" => "ASC"], $arFilter, false, false, ['ID', 'IBLOCK_ID', 'NAME']);
        while ($res = $list->Fetch()) {
            $arResult[] = [
                'ID' => $res['ID'],
                'NAME' => $res['NAME'],
            ];
        }
        $this->arResult = $arResult;

    }

//    public function onPrepareComponentParams($arParams)
//    {
//        if (!isset($arParams['CACHE_TIME'])) {
//            $arParams['CACHE_TIME'] = 3600;
//        } else {
//            $arParams['CACHE_TIME'] = intval($arParams['CACHE_TIME']);
//        }
//        return $arParams;
//    }

}
