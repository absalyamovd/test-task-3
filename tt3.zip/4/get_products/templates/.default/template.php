<?php
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

foreach ($arResult as $key => $value){
    echo '<div>';
    echo $value['ID'].', '.$value['NAME'].PHP_EOL;
    echo '</div>';
}
