<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = [
	"NAME" => "Вывести товары из указанного раздела",
	"DESCRIPTION" => "Тестовое задание `Вывести товары из указанного раздела`",
	"CACHE_PATH" => "Y",
	"SORT" => 100,
	"PATH" => [
        "ID" => "testtask3",
        "NAME" => "Тестовое задание 3",
	],
];
