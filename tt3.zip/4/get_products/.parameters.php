<?php if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Loader;

//Bitrix\Main\ModuleManager,
//Bitrix\Iblock,
//Bitrix\Catalog;

if (!Loader::includeModule('iblock'))
    return;

//$catalogIncluded = Loader::includeModule('catalog');
//CBitrixComponent::includeComponentClass($componentName);

//тип ИБ
$arIBlockType = CIBlockParameters::GetIBlockTypes();

//ИБ
$arIBlock = [];

$rsIBlock = CIBlock::GetList(["SORT" => "ASC"], ["TYPE" => $arCurrentValues["IBLOCK_TYPE"], "ACTIVE" => "Y"]);
while ($arr = $rsIBlock->Fetch()) {
    $id = (int)$arr['ID'];
    $arIBlock[$id] = '[' . $id . '] ' . $arr['NAME'];
}
unset($id, $arr, $rsIBlock);

//ID раздела
$arFilter = [
    'IBLOCK_ID' => $arCurrentValues["IBLOCK_ID"],
    'GLOBAL_ACTIVE' => 'Y',
];
$sectionList = CIBlockSection::GetList(["SORT"=>"ASC"], $arFilter, false, ["ID", "NAME"],false);
while ($arr = $sectionList->GetNext()) {
    $id = (int)$arr['ID'];
    $arSection[$id] = '[' . $id . '] ' . $arr['NAME'];
}

$arComponentParameters = array(
    "GROUPS" => [],
    "PARAMETERS" => [
        "IBLOCK_TYPE" => [
            "NAME" => "Тип ИБ",
            "PARENT" => "DATA_SOURCE",
            "SORT" => 10,
            "TYPE" => "LIST",
            "VALUES" => $arIBlockType,
            "ADDITIONAL_VALUES" => "Y",
            "REFRESH" => "Y",
            "MULTIPLE" => "N",
        ],
        "IBLOCK_ID" => [
            "NAME" => "ИБ",
            "PARENT" => "DATA_SOURCE",
            "SORT" => 20,
            "TYPE" => "LIST",
            "VALUES" => $arIBlock,
            "ADDITIONAL_VALUES" => "Y",
            "REFRESH" => "Y",
            "MULTIPLE" => "N",
        ],
        "SECTION_ID" => [
            "NAME" => "Раздел",
            "PARENT" => "DATA_SOURCE",
            "SORT" => 30,
            "TYPE" => "LIST",
            "VALUES" => $arSection,
            "ADDITIONAL_VALUES" => "Y",
            "REFRESH" => "Y",
            "MULTIPLE" => "N",
        ]
    ]
);
