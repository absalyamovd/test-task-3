<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = [
	"NAME" => "Список всех админов",
	"DESCRIPTION" => "Тестовое задание `Список всех админов`",
	"CACHE_PATH" => "Y",
	"SORT" => 90,
	"PATH" => [
        "ID" => "testtask3",
        "NAME" => "Тестовое задание 3",
	],
];
